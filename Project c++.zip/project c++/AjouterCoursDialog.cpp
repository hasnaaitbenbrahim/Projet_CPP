#include "AjouterCoursDialog.h"
#include "ui_AjouterCoursDialog.h"
#include "dbmanager.h"
#include <QDebug>

AjouterCoursDialog::AjouterCoursDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AjouterCoursDialog)
{
    ui->setupUi(this);

    // Connect signals/slots if needed
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &AjouterCoursDialog::onOkButtonClicked);
}

AjouterCoursDialog::~AjouterCoursDialog()
{
    delete ui;
}

void AjouterCoursDialog::onOkButtonClicked()
{
    // Get data from the UI
    QString nomCours = ui->lineEditNomCours->text();
    QString codeCours = ui->lineEditCodeCours->text();
    QString professeur = ui->lineEditProfesseur->text();

    // Add the course to the database
    DBManager dbManager;
    if (dbManager.openDB()) {
        if (dbManager.addCourse(nomCours, codeCours, professeur)) {
            qDebug() << "Course added successfully.";
            // Emit a signal or perform any additional actions
        } else {
            qDebug() << "Error adding course.";
        }
        dbManager.closeDB();
    }

    // Close the dialog
    accept();
}
