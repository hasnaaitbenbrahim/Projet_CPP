// AjouterCoursDialog.h
#ifndef AJOUTERCOURSDIALOG_H
#define AJOUTERCOURSDIALOG_H

#include <QDialog>
#include "ui_AjouterCoursDialog.h"  // Include the UI header

namespace Ui {
class AjouterCoursDialog;
}

class AjouterCoursDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AjouterCoursDialog(QWidget *parent = nullptr);
    ~AjouterCoursDialog();

private slots:
    void onOkButtonClicked();

private:
    Ui::AjouterCoursDialog *ui;  // Declare the pointer
};

#endif // AJOUTERCOURSDIALOG_H
