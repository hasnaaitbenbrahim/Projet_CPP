// AjouterEtudiantDialog.cpp
#include "AjouterEtudiantDialog.h"
#include "ui_AjouterEtudiantDialog.h"
#include "dbmanager.h"
#include <QDebug>

AjouterEtudiantDialog::AjouterEtudiantDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AjouterEtudiantDialog)
{
    ui->setupUi(this);

    // Connect the "OK" button to a custom slot for handling the addition of a student
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &AjouterEtudiantDialog::onOKButtonClicked);
}

AjouterEtudiantDialog::~AjouterEtudiantDialog()
{
    delete ui;
}

void AjouterEtudiantDialog::onOKButtonClicked()
{
    // Get data from the UI
    QString nom = getNom();
    QString prenom = getPrenom();
    QString numeroEtudiant = getNumeroEtudiant();

    // Validate data if needed

    // Add the student to the database
    DBManager dbManager;
    if (dbManager.openDB()) {
        if (dbManager.addStudent(nom, prenom, numeroEtudiant)) {
            qDebug() << "Student added successfully.";
        } else {
            qDebug() << "Error adding student.";
        }
        dbManager.closeDB();
    }

    // Close the dialog
    accept();
}

QString AjouterEtudiantDialog::getNom() const
{
    return ui->lineEditNom->text();
}

QString AjouterEtudiantDialog::getPrenom() const
{
    return ui->lineEditPrenom->text();
}

QString AjouterEtudiantDialog::getNumeroEtudiant() const
{
    return ui->lineEditNumeroEtudiant->text();
}
