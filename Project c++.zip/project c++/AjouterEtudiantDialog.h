#ifndef AJOUTERETUDIANTDIALOG_H
#define AJOUTERETUDIANTDIALOG_H

#include <QDialog>

namespace Ui {
class AjouterEtudiantDialog;
}

class AjouterEtudiantDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AjouterEtudiantDialog(QWidget *parent = nullptr);
    ~AjouterEtudiantDialog();

    QString getNom() const;
    QString getPrenom() const;
    QString getNumeroEtudiant() const;

private slots:
    void onOKButtonClicked();

private:
    Ui::AjouterEtudiantDialog *ui;
};

#endif // AJOUTERETUDIANTDIALOG_H
