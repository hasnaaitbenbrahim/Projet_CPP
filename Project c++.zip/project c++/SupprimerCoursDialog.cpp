// SupprimerCoursDialog.cpp
#include "SupprimerCoursDialog.h"
#include "ui_SupprimerCoursDialog.h"
#include "dbmanager.h"
#include <QDebug>

SupprimerCoursDialog::SupprimerCoursDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SupprimerCoursDialog)
{
    ui->setupUi(this);

    // Connect the "Supprimer" button to the slot
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &SupprimerCoursDialog::onSupprimerButtonClicked);
}

SupprimerCoursDialog::~SupprimerCoursDialog()
{
    delete ui;
}

void SupprimerCoursDialog::onSupprimerButtonClicked()
{
    // Get data from the UI
    QString nomCours = ui->lineEditNomCours->text();
    QString codeCours = ui->lineEditCodeCours->text();
    QString professeur = ui->lineEditProfesseur->text();

    // Remove the course from the database
    DBManager dbManager;
    if (dbManager.openDB()) {
        if (dbManager.removeCourse(nomCours, codeCours, professeur)) {
            qDebug() << "Course removed successfully.";
            // Add any additional actions or signals here
        } else {
            qDebug() << "Error removing course.";
        }
        dbManager.closeDB();
    }

    // Close the dialog
    accept();
}
