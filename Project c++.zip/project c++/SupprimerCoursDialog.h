// SupprimerCoursDialog.h
#ifndef SUPPRIMERCOURSDIALOG_H
#define SUPPRIMERCOURSDIALOG_H

#include <QDialog>

namespace Ui {
class SupprimerCoursDialog;
}

class SupprimerCoursDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SupprimerCoursDialog(QWidget *parent = nullptr);
    ~SupprimerCoursDialog();

private slots:
    void onSupprimerButtonClicked();

private:
    Ui::SupprimerCoursDialog *ui;
};

#endif // SUPPRIMERCOURSDIALOG_H
