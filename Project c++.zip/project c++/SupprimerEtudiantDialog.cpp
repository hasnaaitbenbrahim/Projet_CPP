// SupprimerEtudiantDialog.cpp
#include "SupprimerEtudiantDialog.h"
#include "ui_SupprimerEtudiantDialog.h"
#include "dbmanager.h"
#include <QDebug>

SupprimerEtudiantDialog::SupprimerEtudiantDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SupprimerEtudiantDialog)
{
    ui->setupUi(this);

    // Connect the "Supprimer" button to accept the dialog
    connect(ui->pushButtonSupprimer, &QPushButton::clicked, this, &SupprimerEtudiantDialog::onSupprimerButtonClicked);
}

SupprimerEtudiantDialog::~SupprimerEtudiantDialog()
{
    delete ui;
}

void SupprimerEtudiantDialog::onSupprimerButtonClicked()
{
    // Get data from the UI
    QString numeroEtudiant = getNumeroEtudiant();

    // Validate data if needed

    // Remove the student from the database
    DBManager dbManager;
    if (dbManager.removeStudent(numeroEtudiant)) {
        qDebug() << "Student removed successfully.";
        // Emit signal to notify that a student has been deleted
        emit studentDeleted();
    } else {
        qDebug() << "Error removing student.";
    }

    // Close the dialog
    accept();
}

QString SupprimerEtudiantDialog::getNumeroEtudiant() const
{
    return ui->lineEditNumeroEtudiant->text();
}
