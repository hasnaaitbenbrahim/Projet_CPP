// SupprimerEtudiantDialog.h
#ifndef SUPPRIMERETUDIANTDIALOG_H
#define SUPPRIMERETUDIANTDIALOG_H

#include <QDialog>

namespace Ui {
class SupprimerEtudiantDialog;
}

class SupprimerEtudiantDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SupprimerEtudiantDialog(QWidget *parent = nullptr);
    ~SupprimerEtudiantDialog();

    QString getNumeroEtudiant() const;

signals:
    void studentDeleted();

private slots:
    void onSupprimerButtonClicked();

private:
    Ui::SupprimerEtudiantDialog *ui;
};

#endif // SUPPRIMERETUDIANTDIALOG_H
