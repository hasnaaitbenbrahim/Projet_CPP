// dbmanager.cpp
#include "dbmanager.h"

QSqlDatabase DBManager::db = QSqlDatabase::addDatabase("QSQLITE");

DBManager::DBManager()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("P:/programming/c++/projectCpp/sqliteDB.db");
    openDB();
    createTables();
}

DBManager::~DBManager()
{
    closeDB();
}

bool DBManager::openDB()
{
    if (!db.open()) {
        qDebug() << "Error: Couldn't open the database";
        return false;
    }
    return true;
}

void DBManager::closeDB()
{
    db.close();
}

bool DBManager::createTables()
{
    QSqlQuery query;

    // Table Etudiant
    query.exec("CREATE TABLE IF NOT EXISTS Etudiant ("
               "id_etudiant INTEGER PRIMARY KEY,"
               "nom TEXT NOT NULL,"
               "prenom TEXT NOT NULL,"
               "numero_etudiant TEXT UNIQUE NOT NULL)");

    // Table Cours
    query.exec("CREATE TABLE IF NOT EXISTS Cours ("
               "id_cours INTEGER PRIMARY KEY,"
               "nom_cours TEXT NOT NULL,"
               "code_cours TEXT UNIQUE NOT NULL,"
               "professeur TEXT NOT NULL)");

    // Table Inscription
    query.exec("CREATE TABLE IF NOT EXISTS Inscription ("
               "id_inscription INTEGER PRIMARY KEY,"
               "id_etudiant INTEGER,"
               "id_cours INTEGER,"
               "date_inscription DATE,"
               "notes TEXT,"
               "FOREIGN KEY (id_etudiant) REFERENCES Etudiant(id_etudiant),"
               "FOREIGN KEY (id_cours) REFERENCES Cours(id_cours))");

    return true;
}

int DBManager::getStudentId(const QString& numeroEtudiant)
{
    QSqlQuery query;
    query.prepare("SELECT id_etudiant FROM Etudiant WHERE numero_etudiant = :numeroEtudiant");
    query.bindValue(":numeroEtudiant", numeroEtudiant);
    query.exec();

    if (query.next()) {
        return query.value(0).toInt();
    }

    return -1;
}

int DBManager::getCourseId(const QString& codeCours)
{
    QSqlQuery query;
    query.prepare("SELECT id_cours FROM Cours WHERE code_cours = :codeCours");
    query.bindValue(":codeCours", codeCours);
    query.exec();

    if (query.next()) {
        return query.value(0).toInt();
    }

    return -1;
}

bool DBManager::addStudent(const QString& nom, const QString& prenom, const QString& numeroEtudiant)
{
    QSqlQuery query;
    query.prepare("INSERT INTO Etudiant (nom, prenom, numero_etudiant) VALUES (:nom, :prenom, :numeroEtudiant)");
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":numeroEtudiant", numeroEtudiant);

    if (query.exec()) {
        return true;
    } else {
        qDebug() << "Error adding student:" << query.lastError().text();
        return false;
    }
}

bool DBManager::addCourse(const QString& nomCours, const QString& codeCours, const QString& professeur)
{
    QSqlQuery query;
    query.prepare("INSERT INTO Cours (nom_cours, code_cours, professeur) VALUES (:nomCours, :codeCours, :professeur)");
    query.bindValue(":nomCours", nomCours);
    query.bindValue(":codeCours", codeCours);
    query.bindValue(":professeur", professeur);

    if (query.exec()) {
        return true;
    } else {
        qDebug() << "Error adding course:" << query.lastError().text();
        return false;
    }
}

bool DBManager::enrollStudentInCourse(int idEtudiant, int idCours, const QString& dateInscription, const QString& notes)
{
    QSqlQuery query;
    query.prepare("INSERT INTO Inscription (id_etudiant, id_cours, date_inscription, notes) VALUES (:idEtudiant, :idCours, :dateInscription, :notes)");
    query.bindValue(":idEtudiant", idEtudiant);
    query.bindValue(":idCours", idCours);
    query.bindValue(":dateInscription", dateInscription);
    query.bindValue(":notes", notes);

    if (query.exec()) {
        return true;
    } else {
        qDebug() << "Error enrolling student in course:" << query.lastError().text();
        return false;
    }
}

bool DBManager::removeStudent(const QString& studentNumber)
{
    // Implementation of removing a student from the database
    // You need to execute a SQL query to delete the student with the given studentNumber
    QSqlQuery query;
    query.prepare("DELETE FROM Students WHERE StudentNumber = :studentNumber");
    query.bindValue(":studentNumber", studentNumber);

    if (query.exec()) {
        // Successful execution
        return true;
    } else {
        // Error occurred, handle the error
        qDebug() << "Error removing student:" << query.lastError().text();
        return false;
    }
}

QStringList DBManager::getStudentList()
{
    QSqlQuery query;
    query.prepare("SELECT nom, prenom FROM Etudiant");
    query.exec();

    QStringList studentList;

    while (query.next()) {
        QString fullName = query.value(0).toString() + " " + query.value(1).toString();
        studentList.append(fullName);
    }

    return studentList;
}

QStringList DBManager::getCourseList()
{
    QSqlQuery query;
    query.prepare("SELECT nom_cours FROM Cours");
    query.exec();

    QStringList courseList;

    while (query.next()) {
        QString courseName = query.value(0).toString();
        courseList.append(courseName);
    }

    return courseList;
}

QStringList DBManager::getEnrollmentList()
{
    QSqlQuery query;
    query.prepare("SELECT Etudiant.nom, Etudiant.prenom, Cours.nom_cours, Inscription.date_inscription, Inscription.notes "
                  "FROM Inscription "
                  "JOIN Etudiant ON Inscription.id_etudiant = Etudiant.id_etudiant "
                  "JOIN Cours ON Inscription.id_cours = Cours.id_cours");
    query.exec();

    QStringList enrollmentList;

    while (query.next()) {
        QString enrollmentDetails = query.value(0).toString() + " " + query.value(1).toString() + " - " +
                                    query.value(2).toString() + " (" + query.value(3).toString() + "): " +
                                    query.value(4).toString();
        enrollmentList.append(enrollmentDetails);
    }

    return enrollmentList;
}

bool DBManager::removeCourse(const QString& nomCours, const QString& codeCours, const QString& professeur)
{
    QSqlQuery query;
    query.prepare("DELETE FROM Cours WHERE nom_cours = :nomCours AND code_cours = :codeCours AND professeur = :professeur");
    query.bindValue(":nomCours", nomCours);
    query.bindValue(":codeCours", codeCours);
    query.bindValue(":professeur", professeur);

    if (query.exec()) {
        return true;
    } else {
        qDebug() << "Error removing course:" << query.lastError().text();
        return false;
    }
}
