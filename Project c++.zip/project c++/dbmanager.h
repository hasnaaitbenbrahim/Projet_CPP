// dbmanager.h
#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <QtSql>
#include <QString>

class DBManager
{
public:
    DBManager();
    ~DBManager();

    bool openDB();
    void closeDB();

    bool addStudent(const QString& nom, const QString& prenom, const QString& numeroEtudiant);
    bool addCourse(const QString& nomCours, const QString& codeCours, const QString& professeur);
    bool enrollStudentInCourse(int idEtudiant, int idCours, const QString& dateInscription, const QString& notes);
    bool removeStudent(const QString& studentNumber);
    bool removeCourse(const QString& nomCours, const QString& codeCours, const QString& professeur);

    bool deleteStudentById(int studentId); // New method

    QStringList getStudentList();
    QStringList getCourseList();
    QStringList getEnrollmentList();

private:
    static QSqlDatabase db;
    QSqlDatabase m_database;

    bool createTables();
    int getStudentId(const QString& numeroEtudiant);
    int getCourseId(const QString& codeCours);
};

#endif // DBMANAGER_H
