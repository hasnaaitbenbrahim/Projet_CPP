// mainwindow.cpp
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    ajouterEtudiantDialog(nullptr),
    supprimerEtudiantDialog(new SupprimerEtudiantDialog(this)),
    ajouterCoursDialog(new AjouterCoursDialog(this)),
    supprimerCoursDialog(new SupprimerCoursDialog(this))
{
    ui->setupUi(this);

    // Connexion à la base de données SQLite
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("P:/programming/c++/projectCpp/sqliteDB.db");
    if (!db.open()) {
        qDebug() << "Erreur lors de l'ouverture de la base de données :" << db.lastError().text();
    } else {
        qDebug() << "Connexion à la base de données établie avec succès khalid.";
    }

    // Create AjouterEtudiantDialog after setting up the database connection
    ajouterEtudiantDialog = new AjouterEtudiantDialog(this);

    // Connect signals/slots for menu actions
    connect(ui->actionajoute_un_etudiat, SIGNAL(triggered()), this, SLOT(onAjouteUnEtudiant()));
    connect(ui->actionsupprimer_un_etudiat, SIGNAL(triggered()), this, SLOT(onSupprimerUnEtudiant()));
    connect(ui->actionsupprimer_un_cours, &QAction::triggered, this, &MainWindow::onSupprimerCoursAction);

    connect(supprimerEtudiantDialog, &SupprimerEtudiantDialog::studentDeleted, this, &MainWindow::onStudentDeleted);

    // Connect the AjouterCoursDialog to the menu action
    connect(ui->actionajouter_un_cours, &QAction::triggered, ajouterCoursDialog, &AjouterCoursDialog::exec);

    // Connect Quit action
    connect(ui->actionQuitter, SIGNAL(triggered()), this, SLOT(on_actionQuitter_triggered()));
}

MainWindow::~MainWindow()
{
    delete ui;
    delete ajouterEtudiantDialog;
    delete supprimerEtudiantDialog;
}

void MainWindow::onAjouteUnEtudiant()
{
    ajouterEtudiantDialog->exec();
    // Handle data after closing the dialog if needed
}

void MainWindow::onSupprimerUnEtudiant()
{
    supprimerEtudiantDialog->exec();
    // Handle data after closing the dialog if needed
}

void MainWindow::onSupprimerCoursAction()
{
    supprimerCoursDialog->exec();
    // Handle data after closing the dialog if needed
}

void MainWindow::on_actionajouter_un_cours_triggered()
{
    // Code for handling the action
}

void MainWindow::on_actionsupprimer_un_cours_triggered()
{
    // Code for handling the action
}

void MainWindow::onAjouterCoursAction()
{
    // Code for handling the action
}

void MainWindow::on_actionajoute_un_etudiat_triggered()
{
    // Code for handling the action
}

void MainWindow::on_actionsupprimer_un_etudiat_triggered()
{
    // Code for handling the action
}

void MainWindow::on_actionQuitter_triggered()
{
    // Handle Quit Action
    qApp->quit();
    // Or use close() to close the main window if you prefer:
    // close();
    // Note: This will close the application.
    // If you want to close only the main window and keep the application running,
    // you may need to handle that accordingly.
}
void MainWindow::onStudentDeleted()
{
    // Handle the studentDeleted signal here
    qDebug() << "Student deleted signal received.";
}
