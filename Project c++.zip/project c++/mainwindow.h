// mainwindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QMenu>
#include <QAction>
#include <QMenuBar>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include "AjouterEtudiantDialog.h"
#include "SupprimerEtudiantDialog.h"
#include "AjouterCoursDialog.h"
#include "SupprimerCoursDialog.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QSqlDatabase db;
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onAjouteUnEtudiant();
    void onSupprimerUnEtudiant();
    void onAjouterCoursAction();
    void onSupprimerCoursAction();
    void on_actionajoute_un_etudiat_triggered();
    void on_actionsupprimer_un_etudiat_triggered();
    void on_actionajouter_un_cours_triggered();
    void on_actionsupprimer_un_cours_triggered();
    void on_actionQuitter_triggered();

    // Add the following slot declaration
    void onStudentDeleted();

private:
    Ui::MainWindow *ui;
    AjouterEtudiantDialog *ajouterEtudiantDialog;
    SupprimerEtudiantDialog *supprimerEtudiantDialog;
    AjouterCoursDialog* ajouterCoursDialog;
    SupprimerCoursDialog* supprimerCoursDialog;
};

#endif // MAINWINDOW_H
